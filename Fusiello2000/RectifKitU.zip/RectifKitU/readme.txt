Epipolar Rectification Toolkit

Andrea Fusiello (andrea.fusiello@univr.it)  2007. 


The main file is  rectifyImage.m. In order to test it, type
>> rectifyImageU('cporta')

The user must provide his own images (a stereo pair) in the directory 'images' and the
correspondences in the directory 'data' (see example).

The use of the jacobian can be switched on or off (it makes the
algorithm slower but slightly more precise).

 
-------------------------------------------------------------------------------

Last modified 17/05/07

 
   			Andrea Fusiello

			Dipartimento di Informatica
			Universita' degli Studi di Verona  
			Ca' Vignal 2, Strada Le Grazie,  
			
			E-mail: andrea.fusiello@univr.it 
			Tel.: +39 (045) 802 7088 
			Fax:  +39 (045) 802 7928 
			HTTP: www.sci.univr.it/~fusiello/ 
