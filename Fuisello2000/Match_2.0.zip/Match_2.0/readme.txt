- Serve il package SIFT di Vedaldi nel path;
- Serve il package di funzioni di Kovesi nel path; 
- Servono le funzioni di Phil Torr nel path;
- Servono le funzioni VGG di Zisserman nel path;
- leggere  la linea 127 di ransac.m (Kovesi) e modificare di conseguenza;
- ransacfithomography.m oroginale di Kovesi aveva un bug, controllare di
   avere la versione con il mio fix (Andrea Fusiello)
   
Il file principale e' matchbySIFT.m (v. help).


